const express = require('express');
const mqtt = require('mqtt');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

let systemLogs = [];

const TOPICS = {
    cmd_lock: 'home/security/lock/cmd', 
    cmd_door: 'home/security/door/cm1',  
    status_pattern: 'home/security/+/status'
};

const mqttClient = mqtt.connect('mqtts://023ef5e7dc384a739b05409b387ae2f0.s1.eu.hivemq.cloud', {
    port: 8883,        
    username: 'user11', 
    password: 'user11ABC'
});

mqttClient.on('connect', () => {
    console.log("✅ MQTT Connected");
    mqttClient.subscribe(TOPICS.status_pattern); 
});

mqttClient.on('message', (topic, message) => {
    
    const parts = topic.split('/'); 
    const deviceType = parts[2];
    const msg = message.toString();
    
    const deviceName = deviceType === 'lock' ? 'ระบบล็อค (Lock)' : 'บานประตู (Door)';

    const newLog = {
        deviceType: deviceType,
        deviceName: deviceName,
        status: msg,
        timestamp: new Date().toLocaleString('th-TH')
    };

    console.log(`📩 Log: [${deviceName}] -> ${msg}`);
    
    systemLogs.unshift(newLog);
    
    if (systemLogs.length > 50) systemLogs.pop();
});

app.get('/api/logs', (req, res) => {
    res.json(systemLogs);
});

app.post('/api/control', (req, res) => {
    const { device, command } = req.body; 
    
    if (device === 'lock') {
        mqttClient.publish(TOPICS.cmd_lock, command);
        console.log(`⬆️ สั่งงานกลอน: ${command}`);
    } else if (device === 'door') {
        mqttClient.publish(TOPICS.cmd_door, command);
        console.log(`⬆️ สั่งงานประตู: ${command}`);
    } else {
        return res.status(400).send({ error: 'Unknown device' });
    }
    
    res.status(200).send({ msg: 'Command Sent' });
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`🚀 Server running on port ${PORT}`);
});