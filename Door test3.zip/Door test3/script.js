const API_BASE = 'http://localhost:3000/api';

const lockSwitch = document.getElementById('lockSwitch');
const lockLabel = document.getElementById('lockLabel');
const doorSwitch = document.getElementById('doorSwitch');
const doorLabel = document.getElementById('doorLabel');
const warningText = document.getElementById('warningText');
const logTableBody = document.getElementById('logTableBody');
const lastUpdateSpan = document.getElementById('lastUpdate');
const btnRefresh = document.getElementById('btnRefresh');

let isUserInteracting = false;
let syncTimeout = null;

async function fetchLogs() {
    try {
        const response = await fetch(`${API_BASE}/logs`);
        if (!response.ok) throw new Error("Server Error");
        const logs = await response.json();

        renderTable(logs);
        
        if (!isUserInteracting && logs.length > 0) {
            syncUIState(logs);
        }

        lastUpdateSpan.textContent = `อัปเดต: ${new Date().toLocaleTimeString('th-TH')}`;

    } catch (error) {
        console.error(error);
        lastUpdateSpan.textContent = "Connecting...";
    }
}

function renderTable(logs) {
    let html = '';
    if (logs.length === 0) {
        html = '<tr><td colspan="3" style="text-align:center;">ไม่มีประวัติ</td></tr>';
    } else {
        logs.forEach(log => {
            let color = '#333';
            
            if (['UNLOCK', 'OPEN'].includes(log.status)) color = '#2ecc71';
            if (['LOCK', 'CLOSE'].includes(log.status)) color = '#e74c3c';

            html += `
                <tr>
                    <td><strong>${log.deviceName}</strong></td>
                    <td style="color:${color}; font-weight:bold;">${log.status}</td>
                    <td>${log.timestamp}</td>
                </tr>
            `;
        });
    }
    logTableBody.innerHTML = html;
}

function syncUIState(logs) {
    
    const lastLock = logs.find(l => l.deviceType === 'lock');
    const lastDoor = logs.find(l => l.deviceType === 'door');

    if (lastLock) {
        const isUnlocked = (lastLock.status === 'UNLOCK');
        if (lockSwitch.checked !== isUnlocked) {
            lockSwitch.checked = isUnlocked;
            updateLockUI(isUnlocked);
        }
    }

    if (lastDoor) {
        const isOpen = (lastDoor.status === 'OPEN');
        if (doorSwitch.checked !== isOpen) {
            doorSwitch.checked = isOpen;
            updateDoorUI(isOpen);
        }
    }
}

function updateLockUI(isUnlocked) {
    if (isUnlocked) {
        lockLabel.innerText = "สถานะ: ปลดล็อค (UNLOCKED)";
        lockLabel.style.color = "#2ecc71";
        doorSwitch.disabled = false;
        warningText.style.display = 'none';
    } else {
        lockLabel.innerText = "สถานะ: ล็อค (LOCKED)";
        lockLabel.style.color = "#e74c3c";
        doorSwitch.disabled = true;
        warningText.style.display = 'block';
        
        if(doorSwitch.checked) {
            doorSwitch.checked = false;
            updateDoorUI(false);
        }
    }
}

function updateDoorUI(isOpen) {
    if (isOpen) {
        doorLabel.innerText = "สถานะ: เปิดประตู (OPEN)";
        doorLabel.style.color = "#3498db";
    } else {
        doorLabel.innerText = "สถานะ: ปิดสนิท (CLOSED)";
        doorLabel.style.color = "#7f8c8d";
    }
}

async function sendCommand(device, command) {
    
    isUserInteracting = true;
    
    if (syncTimeout) clearTimeout(syncTimeout);

    try {
        await fetch(`${API_BASE}/control`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ device, command })
        });
        
        syncTimeout = setTimeout(() => {
            isUserInteracting = false;
            fetchLogs();
        }, 2000);

    } catch (err) {
        console.error(err);
        isUserInteracting = false;
    }
}

lockSwitch.addEventListener('change', function() {
    const isUnlocked = this.checked;
    updateLockUI(isUnlocked);
    const cmd = isUnlocked ? 'UNLOCK' : 'LOCK';
    sendCommand('lock', cmd);
    if (!isUnlocked) sendCommand('door', 'CLOSE'); 
});

doorSwitch.addEventListener('change', function() {
    const isOpen = this.checked;
    updateDoorUI(isOpen);
    const cmd = isOpen ? 'OPEN' : 'CLOSE';
    sendCommand('door', cmd);
});

btnRefresh.addEventListener('click', fetchLogs);

updateLockUI(lockSwitch.checked);
fetchLogs();
setInterval(fetchLogs, 1000);